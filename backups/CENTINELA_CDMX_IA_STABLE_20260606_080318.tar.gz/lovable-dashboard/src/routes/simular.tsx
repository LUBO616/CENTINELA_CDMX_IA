import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Send,
  Loader2,
  AlertCircle,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Copy,
  Check,
} from "lucide-react";
import { postCall, type CallResult, type CallPayload } from "@/lib/centinela-api";

export const Route = createFileRoute("/simular")({
  head: () => ({
    meta: [
      { title: "Simular llamada · CENTINELA CDMX IA" },
      { name: "description", content: "Envía un transcript sintético al flujo de clasificación." },
    ],
  }),
  component: SimulatePage,
});

const EXAMPLES = [
  {
    key: "low" as const,
    label: "Bajo riesgo",
    desc: "Bache o alumbrado",
    icon: ShieldCheck,
    transcript:
      "Hola, quería reportar un bache muy grande sobre la avenida principal cerca de la esquina. Ya rompió la llanta de un coche. También hay un poste de alumbrado que no enciende desde hace varios días.",
    location_hint: "Zona urbana — colonia ejemplo",
  },
  {
    key: "mid" as const,
    label: "Riesgo medio",
    desc: "Accidente sin lesionados confirmados",
    icon: AlertTriangle,
    transcript:
      "Acaba de haber un choque entre dos autos en la avenida. Los conductores están discutiendo pero al parecer nadie está herido. Está bloqueando un carril.",
    location_hint: "Cruce de avenida — referencia parque",
  },
  {
    key: "critical" as const,
    label: "Crítico P0",
    desc: "Incendio, niño herido o inconsciente",
    icon: Flame,
    transcript:
      "¡Por favor ayuda! Hay un incendio en el edificio de al lado, sale mucho humo y veo a un niño herido en la banqueta, no se mueve, creo que está inconsciente.",
    location_hint: "Edificio multifamiliar — referencia esquina",
  },
];

function SimulatePage() {
  const [transcript, setTranscript] = useState("");
  const [locationHint, setLocationHint] = useState("");
  const [consent, setConsent] = useState(true);

  const mutation = useMutation({
    mutationFn: (payload: CallPayload) => postCall(payload),
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transcript.trim()) return;
    mutation.mutate({
      transcript: transcript.trim(),
      location_hint: locationHint.trim(),
      solid_consent: consent,
      metadata: { source: "lovable_dashboard" },
    });
  };

  const loadExample = (k: (typeof EXAMPLES)[number]["key"]) => {
    const ex = EXAMPLES.find((e) => e.key === k)!;
    setTranscript(ex.transcript);
    setLocationHint(ex.location_hint);
    setConsent(true);
    mutation.reset();
  };

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <section className="lg:col-span-3">
        <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
          Simular llamada
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Envía un transcript sintético al webhook de n8n para clasificarlo.
        </p>

        <div className="mt-5 grid gap-2 sm:grid-cols-3">
          {EXAMPLES.map((ex) => {
            const Icon = ex.icon;
            const tone =
              ex.key === "low"
                ? "border-risk-low/40 hover:bg-risk-low/10 text-risk-low"
                : ex.key === "mid"
                  ? "border-risk-mid/40 hover:bg-risk-mid/10 text-risk-mid"
                  : "border-risk-critical/40 hover:bg-risk-critical/10 text-risk-critical";
            return (
              <button
                key={ex.key}
                type="button"
                onClick={() => loadExample(ex.key)}
                className={[
                  "group rounded-lg border bg-card p-3 text-left transition-colors",
                  tone,
                ].join(" ")}
              >
                <div className="flex items-center gap-2">
                  <Icon className="h-4 w-4" />
                  <span className="text-xs font-semibold uppercase tracking-wider">
                    {ex.label}
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{ex.desc}</p>
              </button>
            );
          })}
        </div>

        <form onSubmit={onSubmit} className="mt-6 space-y-4 rounded-xl border border-border bg-card p-5">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Transcript
            </label>
            <textarea
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              rows={6}
              maxLength={4000}
              placeholder="Describa el evento como si fuera la transcripción de una llamada (datos sintéticos)."
              className="w-full resize-y rounded-md border border-input bg-background px-3 py-2 text-sm outline-none ring-primary/40 focus:ring-2"
              required
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Location hint
            </label>
            <input
              value={locationHint}
              onChange={(e) => setLocationHint(e.target.value)}
              maxLength={200}
              placeholder="Referencia general (no direcciones reales)"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none ring-primary/40 focus:ring-2"
            />
          </div>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-input bg-background accent-[oklch(0.72_0.16_240)]"
            />
            <span>
              <span className="font-medium">solid_consent</span>
              <span className="ml-1 text-muted-foreground">
                — el usuario otorga consentimiento para procesar la llamada (demo).
              </span>
            </span>
          </label>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              disabled={mutation.isPending || !transcript.trim()}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {mutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              Procesar llamada
            </button>
            {mutation.isError && (
              <span className="inline-flex items-center gap-1.5 text-xs text-destructive">
                <AlertCircle className="h-4 w-4" />
                Error al contactar el webhook. Revisa que el endpoint esté activo.
              </span>
            )}
          </div>
        </form>
      </section>

      <section className="lg:col-span-2">
        <ResultPanel
          result={mutation.data}
          isPending={mutation.isPending}
          error={mutation.error as Error | null}
        />
      </section>
    </div>
  );
}

function ResultPanel({
  result,
  isPending,
  error,
}: {
  result?: CallResult;
  isPending: boolean;
  error: Error | null;
}) {
  if (isPending) {
    return (
      <div className="grid h-full min-h-[300px] place-items-center rounded-xl border border-dashed border-border bg-card/50 p-6 text-center">
        <div>
          <Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" />
          <p className="mt-3 text-sm text-muted-foreground">Procesando llamada…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-5">
        <div className="flex items-center gap-2 text-destructive">
          <AlertCircle className="h-5 w-5" />
          <h3 className="font-semibold">El webhook falló</h3>
        </div>
        <p className="mt-2 text-sm text-destructive/90">{error.message}</p>
        <p className="mt-2 text-xs text-muted-foreground">
          Verifica que <code className="font-mono">VITE_N8N_WEBHOOK_URL</code> apunte a un endpoint activo.
        </p>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="grid h-full min-h-[300px] place-items-center rounded-xl border border-dashed border-border bg-card/50 p-6 text-center text-sm text-muted-foreground">
        Envía una llamada para ver el resultado de clasificación.
      </div>
    );
  }

  return <ResultCard result={result} />;
}

function ResultCard({ result }: { result: CallResult }) {
  const [copied, setCopied] = useState(false);
  const risk = String(result.branch ?? "").toLowerCase();
  const tone =
    risk === "critical"
      ? "border-risk-critical/50 ring-risk-critical/30"
      : risk === "mid"
        ? "border-risk-mid/50 ring-risk-mid/30"
        : risk === "low"
          ? "border-risk-low/50 ring-risk-low/30"
          : "border-border ring-border";

  const copy = () => {
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className={["rounded-xl border bg-card p-5 ring-1", tone].join(" ")}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Resultado
          </div>
          <div className="mt-1 flex items-center gap-2">
            <RiskBadge level={result.branch} />
            {result.human_required && (
              <span className="rounded-full border border-analytics/40 bg-analytics/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-analytics">
                Requiere humano
              </span>
            )}
          </div>
        </div>
        <button
          onClick={copy}
          className="rounded-md border border-border bg-background p-1.5 text-muted-foreground transition-colors hover:text-foreground"
          title="Copiar JSON"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        </button>
      </div>

      {result.public_stage_phrase && (
        <p className="mt-4 rounded-md border border-border bg-background/60 p-3 text-sm italic text-foreground">
          “{result.public_stage_phrase}”
        </p>
      )}

      <dl className="mt-4 grid grid-cols-1 gap-x-4 gap-y-2.5 text-sm sm:grid-cols-2">
        <Field label="call_id" value={result.call_id} mono />
        <Field label="trace_id" value={result.trace_id} mono />
        <Field label="incident_id" value={result.incident_id} mono />
        <Field label="branch" value={result.branch} />
        <Field label="case_category" value={result.case_category} />
        <Field label="primary_authority" value={result.primary_authority} />
        <Field
          label="support_authorities"
          value={
            Array.isArray(result.support_authorities)
              ? result.support_authorities.join(", ")
              : undefined
          }
        />
        <Field
          label="p0_signals"
          value={
            Array.isArray(result.p0_signals)
              ? result.p0_signals.length
                ? result.p0_signals.join(", ")
                : "ninguna"
              : result.p0_signals
                ? JSON.stringify(result.p0_signals)
                : "ninguna"
          }
        />
        <Field label="processed_at" value={result.processed_at} mono />
      </dl>

      {result.rationale_public && (
        <div className="mt-4">
          <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Rationale público
          </div>
          <p className="mt-1 text-sm text-foreground">{result.rationale_public}</p>
        </div>
      )}

      <details className="mt-4">
        <summary className="cursor-pointer text-xs text-muted-foreground hover:text-foreground">
          Ver JSON completo
        </summary>
        <pre className="mt-2 max-h-72 overflow-auto rounded-md border border-border bg-background/80 p-3 text-[11px] leading-relaxed text-muted-foreground">
          {JSON.stringify(result, null, 2)}
        </pre>
      </details>
    </div>
  );
}

function RiskBadge({ level }: { level?: string }) {
  const l = String(level ?? "unknown").toLowerCase();
  const map: Record<string, string> = {
    low: "bg-risk-low/15 text-risk-low border-risk-low/40",
    mid: "bg-risk-mid/15 text-risk-mid border-risk-mid/40",
    critical: "bg-risk-critical/15 text-risk-critical border-risk-critical/40",
  };
  const cls = map[l] ?? "bg-muted/40 text-muted-foreground border-border";
  return (
    <span
      className={[
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider",
        cls,
      ].join(" ")}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {level ?? "desconocido"}
    </span>
  );
}

function Field({
  label,
  value,
  mono,
}: {
  label: string;
  value?: string | number | null;
  mono?: boolean;
}) {
  return (
    <div>
      <dt className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </dt>
      <dd
        className={[
          "mt-0.5 break-words text-sm text-foreground",
          mono ? "font-mono text-xs" : "",
        ].join(" ")}
      >
        {value ?? <span className="text-muted-foreground">—</span>}
      </dd>
    </div>
  );
}
