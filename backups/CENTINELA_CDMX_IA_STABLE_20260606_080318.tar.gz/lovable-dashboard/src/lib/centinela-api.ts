export type RiskLevel = "low" | "mid" | "critical" | string;

export interface CallResult {
  call_id?: string;
  trace_id?: string;
  risk_level?: RiskLevel;
  branch?: string;
  case_category?: string;
  human_required?: boolean;
  p0_signals?: string[] | Record<string, unknown>;
  primary_authority?: string;
  support_authorities?: string[];
  incident_id?: string;
  public_stage_phrase?: string;
  rationale_public?: string;
  processed_at?: string;
  [k: string]: unknown;
}

export interface AnalyticsSummary {
  total_incidents: number;
  low: number;
  mid: number;
  critical: number;
  human_required: number;
  p0_signals: number;
}

export interface AnalyticsPredictions {
  estimated_calls: number;
  trend: "up" | "down" | "stable" | string;
  category_distribution: Record<string, number>;
  risk_zones: { zone: string; score: number }[];
}

const WEBHOOK_URL =
  (import.meta.env.VITE_N8N_WEBHOOK_URL as string) ??
  "http://localhost:5678/webhook/911-call";
const SUMMARY_URL =
  (import.meta.env.VITE_ANALYTICS_SUMMARY_URL as string) ??
  "http://localhost:8003/analytics/summary";
const PREDICTIONS_URL =
  (import.meta.env.VITE_ANALYTICS_PREDICTIONS_URL as string) ??
  "http://localhost:8003/analytics/predictions";

export const MOCK_SUMMARY: AnalyticsSummary = {
  total_incidents: 1284,
  low: 742,
  mid: 389,
  critical: 153,
  human_required: 217,
  p0_signals: 64,
};

export const MOCK_PREDICTIONS: AnalyticsPredictions = {
  estimated_calls: 312,
  trend: "up",
  category_distribution: {
    "Tránsito": 92,
    "Servicios urbanos": 78,
    "Seguridad": 65,
    "Salud": 44,
    "Incendio": 33,
  },
  risk_zones: [
    { zone: "Centro", score: 0.82 },
    { zone: "Iztapalapa", score: 0.74 },
    { zone: "GAM", score: 0.61 },
    { zone: "Coyoacán", score: 0.42 },
    { zone: "Benito Juárez", score: 0.28 },
  ],
};

export async function fetchSummary(): Promise<{ data: AnalyticsSummary; isMock: boolean }> {
  try {
    const r = await fetch(SUMMARY_URL, { method: "GET" });
    if (!r.ok) throw new Error(String(r.status));
    return { data: await r.json(), isMock: false };
  } catch {
    return { data: MOCK_SUMMARY, isMock: true };
  }
}

export async function fetchPredictions(): Promise<{ data: AnalyticsPredictions; isMock: boolean }> {
  try {
    const r = await fetch(PREDICTIONS_URL, { method: "GET" });
    if (!r.ok) throw new Error(String(r.status));
    return { data: await r.json(), isMock: false };
  } catch {
    return { data: MOCK_PREDICTIONS, isMock: true };
  }
}

export interface CallPayload {
  transcript: string;
  location_hint: string;
  solid_consent: boolean;
  metadata: { source: string };
}

export async function postCall(payload: CallPayload): Promise<CallResult> {
  const r = await fetch(WEBHOOK_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!r.ok) throw new Error(`Webhook respondió ${r.status}`);
  const text = await r.text();
  try {
    return JSON.parse(text) as CallResult;
  } catch {
    return { rationale_public: text } as CallResult;
  }
}
